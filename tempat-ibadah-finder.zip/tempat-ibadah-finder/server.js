const express = require('express');
const app = express();

const usersRoutes = require('./routes/users');  
const tempatIbadahRoutes = require('./routes/tempatIbadah');  
const jadwalIbadahRoutes = require('./routes/jadwalIbadah');
const fasilitasRoutes = require('./routes/fasilitas');
const ulasanRoutes = require('./routes/ulasan');
const tempatIbadahRequestRoutes = require('./routes/tempatIbadahRequest');
const tempatIbadahApprovalRoutes = require('./routes/tempatIbadahApproval');

app.use(express.json());

// Gunakan route users dan tempat ibadah
app.use('/users', usersRoutes);
app.use('/tempatIbadah', tempatIbadahRoutes);
app.use('/jadwalIbadah', jadwalIbadahRoutes);
app.use('/fasilitas', fasilitasRoutes);
app.use('/ulasan', ulasanRoutes);
app.use('/tempatIbadahRequest', tempatIbadahRoutes);
app.use('/tempatIbadahApproval', tempatIbadahApprovalRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
